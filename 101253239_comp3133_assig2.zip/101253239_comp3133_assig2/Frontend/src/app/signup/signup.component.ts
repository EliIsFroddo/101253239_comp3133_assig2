import { Component, OnInit } from '@angular/core';
import { Apollo } from "apollo-angular";
import { Router } from '@angular/router';
import gql from "graphql-tag";
//import { adduser } from '../schema';

const SIGNUP_POST = gql`
  mutation SignupPost($sid: Int!, $username: String!, $firstname: String!,$lastname: String!,$email: String!,$password: String!, $type: String!) {
    signup(sid: $sid, username: $username, firstname: $firstname, lastname: $lastname, email: $email, password: $password, type: $type) {
        sid
        
     }
  }
`;


@Component({
  selector: "app-signup",
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.css"]
})

export class SignupComponent  {
  sid: number;
  username: string;
  firstname: string;
  lastname: string;
  email: string;
  password: string; 
  type: string;
 
 constructor(private apollo: Apollo,private router: Router) { }

 signup({ sid, username, firstname, lastname, email, password, type }) {
    this.apollo.mutate({
      mutation: SIGNUP_POST,
      variables: { sid, username, firstname, lastname, email, password, type },
      
    }).subscribe();
  }

}
