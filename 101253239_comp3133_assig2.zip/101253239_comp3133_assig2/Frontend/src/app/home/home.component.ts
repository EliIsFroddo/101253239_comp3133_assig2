import { Component, OnInit } from "@angular/core";
import { Apollo } from "apollo-angular";
import gql from "graphql-tag";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  listings: any[];
  //user: any[];
  //booking: any[]; 
  loading = true;
  error: any;

  constructor(private apollo: Apollo) {}

  ngOnInit() {
    this.apollo
      .query<any>({
        query: gql`
          {
            listings {
              listing_id
              listing_title
              description
              street
              city
              postal_code
              price 
              email
              username
            }
          }
        `
      })
      .subscribe(
        ({ data, loading }) => {
          this.listings = data && data.listings;
          this.loading= loading;
        },
        error => {
          this.loading = false;
          this.error = error;
        }
      );
  }

 /* ngOnInit() {
    this.apollo
      .query<any>({
        query: gql`
          {
            user {
              id
              username
              firstname
              lastname
              email
              password
              type
            }
          }
        `
      })
      .subscribe(
        ({ data, loading }) => {
          this.user = data && data.user;
          this.loading = loading;
        },
        error => {
          this.loading = false;
          this.error = error;
        }
      );
  }

  ngOnInit() {
    this.apollo
      .query<any>({
        query: gql`
          {
            booking{
              listing_id
              booking_id
              booking_date
              booking_start
              booking_end
              username
            }
          }
        `
      })
      .subscribe(
        ({ data, loading }) => {
          this.booking = data && data.booking;
          this.loading = loading;
        },
        error => {
          this.loading = false;
          this.error = error;
        }
      );
  }*/

  getAuthorNames(authors) {
    if (authors.length > 1)
      return authors.reduce((acc, cur) => acc.name + ", " + cur.name);
    else return authors[0].name;
  }
}
