import { Component, OnInit } from "@angular/core";
import { Apollo } from "apollo-angular";
import gql from "graphql-tag";

@Component({
  selector: "app-find",
  templateUrl: "./find.component.html",
  styleUrls: ["./find.component.css"]
})
export class FindComponent {
  listingId: string;
  listings: any = {};
  loading = false;
  error: string;
  constructor(private apollo: Apollo) {}

 /* getAuthorNames(authors) {
    if (authors && authors.length > 1)
      return authors.reduce((acc, cur) => acc.name + ", " + cur.name);
    else if (authors && authors.length == 0) return authors[0].name;
  }*/

  findListing() {
    this.error = "";
    this.loading = true;
    this.apollo
      .query<any>({
        query: gql`
          query($id: ID!) {
            listing(id: $id) {
              title
              description
              street
              city
              postalCode
              price 
            }
          }
        `,
        variables: {
          id: this.listingId
        }
      })
      .subscribe(({ data, loading }) => {
        if (data.listings) this.listings = data.listings;
        else this.error = "Listing does not exits";
        this.loading = loading;
      });
  }
}
