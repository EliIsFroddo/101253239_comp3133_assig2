import { Component, OnInit } from '@angular/core';
import { Apollo } from "apollo-angular";
import gql from "graphql-tag";

@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {
  loading = true;
  error: any;
  bookings: any[];


  constructor(private apollo: Apollo) { }

  ngOnInit() {
    this.apollo
      .query<any>({
        query: gql`
          {
            listings {
              listing_id
              listing_title
              description
              street
              city
              postal_code
              price 
              email
              username
            }
          }
        `
      })
      .subscribe(
        ({ data, loading }) => {
          this.bookings = data && data.bookings;
          this.loading= loading;
        },
        error => {
          this.loading = false;
          this.error = error;
        }
      );
  }

}
