import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { FindComponent } from "./find/find.component";
import { BookingsComponent } from "./bookings/bookings.component";
import { BookingHistoryComponent } from "./booking-history/booking-history.component";
import { AddListingComponent } from "./add-listing/add-listing.component";
import { LoginComponent } from "./login/login.component";
import { SignupComponent } from "./signup/signup.component";
import { ViewListingComponent } from "./view-listing/view-listing.component";



const routes: Routes = [
  { path: "find", component: FindComponent },
  { path: "signup", component: SignupComponent },
  { path: "login", component: LoginComponent },
  { path: "bookings", component: BookingsComponent },
  { path: "booking-history", component: BookingHistoryComponent },
  { path: "add-listing", component: AddListingComponent },
  { path: "view-listing", component: ViewListingComponent },
  { path: "", component: HomeComponent },
  { path: "**", redirectTo: "/", pathMatch: "full" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
