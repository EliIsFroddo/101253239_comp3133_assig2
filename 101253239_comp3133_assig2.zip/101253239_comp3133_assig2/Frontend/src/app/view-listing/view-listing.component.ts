import { Component, OnInit } from '@angular/core';
import { Apollo } from "apollo-angular";
import gql from "graphql-tag";


@Component({
  selector: 'app-view-listing',
  templateUrl: './view-listing.component.html',
  styleUrls: ['./view-listing.component.css']
})
export class ViewListingComponent implements OnInit {
  listings: any[];
  loading = true;
  error: any;

  constructor(private apollo: Apollo) { }

  ngOnInit() {
    this.apollo
      .query<any>({
        query: gql`
          {
            listings {
              listing_id
              listing_title
              description
              street
              city
              postal_code
              price 
              email
              username
            }
          }
        `
      })
      .subscribe(
        ({ data, loading }) => {
          this.listings = data && data.listings;
          this.loading= loading;
        },
        error => {
          this.loading = false;
          this.error = error;
        }
      );
  }

}
